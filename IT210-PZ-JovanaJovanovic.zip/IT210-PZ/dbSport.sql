CREATE TABLE `dbsport`.`orderClothes` (
`id` INT NOT NULL AUTO_INCREMENT ,
`product` VARCHAR(255) NOT NULL ,
`size` VARCHAR(255) NOT NULL ,
`quantity` INT NOT NULL ,
`nameUser` VARCHAR(255) NOT NULL ,
`adress` VARCHAR(255) NOT NULL ,
`phone` VARCHAR(255) NOT NULL ,
PRIMARY KEY (`id`))
ENGINE = InnoDB;

CREATE TABLE `dbsport`.`user` (
 `username` VARCHAR(255) NOT NULL ,
 `email` TEXT NOT NULL ,
 `password` VARCHAR(255) NOT NULL )
 ENGINE = InnoDB;

 ALTER TABLE `user` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`);


CREATE TABLE `dbsport`.`orderEquipment` (
`id` INT NOT NULL AUTO_INCREMENT ,
`product` VARCHAR(255) NOT NULL ,
`quantity` INT NOT NULL ,
`nameUser2` VARCHAR(255) NOT NULL ,
`adress` VARCHAR(255) NOT NULL ,
`phone` VARCHAR(255) NOT NULL ,
PRIMARY KEY (`id`))
ENGINE = InnoDB;

CREATE TABLE `dbsport`.`gym` (
`id` INT NOT NULL AUTO_INCREMENT ,
`name` VARCHAR(255) NOT NULL ,
`age` INT NOT NULL ,
`phone` VARCHAR(255) NOT NULL ,
`typeTraining` VARCHAR(255) NOT NULL ,
PRIMARY KEY (`id`))
ENGINE = InnoDB;

CREATE TABLE `dbsport`.`club` (
 `firstName` VARCHAR(255) NOT NULL ,
 `lastName` VARCHAR(255) NOT NULL ,
 `email` TEXT NOT NULL ,
 `phone` VARCHAR(255) NOT NULL )
 ENGINE = InnoDB;

 ALTER TABLE `club` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`);