<?php

$username_error = $password_error = "";
$username = $password = "";
 if($_SERVER['REQUEST_METHOD'] == "POST") {
     require_once "connectsport.php";
     $username = trim($_POST['username']);
     $password = trim($_POST['password']);
     $sql = "SELECT username, password FROM user WHERE username = ?";
     if ($stmt = mysqli_prepare($conn, $sql)) {
         mysqli_stmt_bind_param($stmt, "s", $param_username);
         $param_username = $username;
         if (mysqli_stmt_execute($stmt)) {
             mysqli_stmt_store_result($stmt);
             if (mysqli_stmt_num_rows($stmt) == 1) {
                 mysqli_stmt_bind_result($stmt, $username, $user_password);
                 if (mysqli_stmt_fetch($stmt)) {
                     if (password_verify($password, $user_password)) {
                         session_start();
                         $_SESSION['username'] = $username;
                         header("location:pocetna.php");
                        } 
                 } else {
                     echo "ERROR: " . mysqli_error();
                 }
             }
         } else {
             echo "ERROR: " . mysqli_error();
         }

     }
     mysqli_stmt_close($stmt);
     mysqli_close($conn);
 }
?>

<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style type="text/css">
        body {
            font: 14px sans-serif;
            font-family: cursive;
            background-color: #cc7ed6;
            margin-left: 500px;
            margin-top: 50px;
        }

        .wrapper {
            margin-top: 40px;
            width: 450px;
            background-color: rgb(220, 160, 255);
            padding: 20px;
            border: 3px solid black;
            border-radius: 10%;
        }
        a{
            color: grey;
        }
        h3{
            text-align: center;
            border-bottom: 1px solid black;
        }
    </style>
</head>
<body>
<div class="wrapper">
<h3>Login Page</h3>
    <p>To login you have to fill every field or go to the link to register if you don't have an account!</p>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
        <div class="form-group">
            <label>Username: </label>
            <input type="text" class="form-control" name="username" placeholder="Enter username" value="<?php echo $username ?>" required>
            <span class="help-block" style="color: rgb(220, 160, 255)"><?php echo $username_error; ?></span>
        </div>
        <div class="form-group">
            <label>Password: </label>
            <input type="password" class="form-control" name="password" placeholder="Enter password" value="<?php echo $password?>" required>
            <span class=" help-block" style="color: rgb(220, 160, 255)"><?php echo $password_error; ?></span>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Submit">
        </div>
        <p>If you don't have an account : <a href="registerDZ12.php">Create new accounnt right here!</a></p>
    </form>
</div>
</body>
</html>