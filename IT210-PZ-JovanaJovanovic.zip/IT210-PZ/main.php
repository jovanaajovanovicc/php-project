<?php
	require_once("connect.php");
	session_start();
	$username = $_SESSION['username'];
	$name = $_SESSION['name'];
	if(!isset($_SESSION['username'])){
		header("Location: pocetna.php");
	}
	
	$stmt = $con->prepare("SELECT * FROM user WHERE username=:username");
	$stmt->bindParam(":username", $username);
	$stmt->execute();
	
	$user = $stmt->fetch();
	$isAdmin = (intval($user["admin"]) == 1 ? true : false);
?>
<html>
	<head>
		<title>Login</title>
	</head>
	<body>
		<a href="logout.php">Logout</a>
		<?php
		if($isAdmin){
		?>
		<h1>Welcome ADMIN!</h1>
		<?php
		}
		else{
		?>
		<h1>Welcome <?php echo $name ?>!</h1>
		<?php
		}
		?>
	</body>
</html>