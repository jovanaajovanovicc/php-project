<html>

<head>
    <title> OnlineSportStore </title>
    <meta name="author" content="Jovana Jovanović" />
    <meta name="description" content="sport" />
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styleShop.css" />
    <link href="sportIcon.jpg" rel="icon" type="image/x-icon" />

</head>

<body>

    <header>

        <div class="nav">

            <ul>
                <h1> Sport selection </h1>
                <h3> Manhattan, NewYork</h3>

                <li class="main"><a href="pocetna.php">MainPage</a></li>
                <li class="offer"><a href="offer.php">Offers</a></li>
                <li class="order"><a href="order.php">OrderClothes</a></li>
                <li class="orderEquipment"><a href="orderEquipment.php">OrderEquipment</a></li>
                <li class="club"><a href="club.php">Club</a></li>
                <li class="gym"><a href="gym.php">Gym</a></li>
                <li class="contact"><a href="contact.php">Contact</a></li>
            </ul>
        </div>

    </header>
    </br></br></br></br></br></br></br></br>


    <section>
        <img class="mySlides" src="sports1.jpg" style="width:100%">
        <img class="mySlides" src="sports2.jpg" style="width:100%">
        <img class="mySlides" src="sports3.jpg" style="width:100%">
    </section>

    <script>
        // Automatic Slideshow - change image every 3 seconds
        var myIndex = 0;
        carousel();

        function carousel() {
            var i;
            var x = document.getElementsByClassName("mySlides");
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";
            }
            myIndex++;
            if (myIndex > x.length) { myIndex = 1 }
            x[myIndex - 1].style.display = "block";
            setTimeout(carousel, 3000);
        }
    </script>


    <h1> Shop here if you want the best clothes!
    </h1>
    </br>


    </br></br></br>
    <footer>
        <p> Copyright &copy;
            <script type="text/javascript"> </script>, Jovana_Jovanović_4491
        </p>
    </footer>

</body>

</html>