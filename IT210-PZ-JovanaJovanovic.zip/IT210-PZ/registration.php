<?php
	session_start();
	if(isset($_SESSION['username'])){
		header("Location: main.php");
	}
?>
<html>
	<head>
		<title>Register</title>
	</head>
	<body>
		<form method="POST" action="register.php">
			<input type="text" name="username" placeholder="Enter username"/><br>
			<input type="password" name="pass" placeholder="Enter password"/><br>
			<input type="text" name="name" placeholder="Enter name"/><br>
			<input type="submit" value="Register"/>
		</form>
	</body>
</html>